library(fpc)
library(xlsx)
library(caret)

#Solving for perfume data
df <- read.xlsx("perfume_data.xlsx", 1, header=FALSE)
df

df2 <- df[2:29]
df2

processParams <- preProcess(df2, method = c("range"))
df2 <- predict(processParams, df2)

dbs <- dbscan(df2, MinPts=2, eps=0.24)
dbs

par(mar=c(4,4,1,1))
plot(dbs, df[1:2])


#Solving for HTRU_2
df <- read.csv("HTRU_2.csv", header=FALSE)
df

df2 <- df[1:8]
df2

hdf <- sample(1:dim(df2)[1],2500)
hdf

htruSample <- df2[hdf,]
htruSample

dbs <- dbscan(htruSample, eps=10, MinPts=30)
dbs

par(mar=c(4,4,1,1))
plot(dbs, df[1:2])

