#Solving for perfume data

library(xlsx)
df <- read.xlsx("perfume_data.xlsx", 1, header=FALSE)
df

df2 <- df[2:29]
df2

hc <- hclust(dist(df2),method="ave")
par(mar=c(1,4,1,4))
plot(hc,hang=-1)



#Solving for HTRU_2
df <- read.csv("HTRU_2.csv", header=FALSE)
df

df2 <- df[1:8]
df2

hdf <- sample(1:dim(df2)[1],30)
hdf

htruSample <- df2[hdf,]
htruSample


hc <- hclust(dist(htruSample),method="ave")

par(mar=c(1,4,1,4))
plot(hc,hang=-1)
