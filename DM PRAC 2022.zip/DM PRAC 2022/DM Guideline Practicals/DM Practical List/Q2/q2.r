library(editrules)

x <- read.csv("https://raw.githubusercontent.com/edwindj/datacleaning/master/data/dirty_iris.csv")
x
# 1
count <- nrow(na.omit(x))
count
percentage <- (count/nrow(x)) * 100
percentage

# 2
x$Sepal.Length[is.nan(x$Sepal.Length)] <- NA
x$Sepal.Width[is.nan(x$Sepal.Width)] <- NA
x$Petal.Length[is.nan(x$Petal.Length)] <- NA
x$Petal.Width[is.nan(x$Petal.Width)] <- NA

x$Sepal.Length[is.infinite(x$Sepal.Length)] <- NA
x$Sepal.Width[is.infinite(x$Sepal.Width)] <- NA
x$Petal.Length[is.infinite(x$Petal.Length)] <- NA
x$Petal.Width[is.infinite(x$Petal.Width)] <- NA

#3
e <- editfile("editRules.txt")
e
#4
ve <- violatedEdits(e, x)
summary(ve)
plot(ve)

# 5
b <- boxplot(Sepal.Length ~ Species, data=x, 
        notch=TRUE,
        main="Box Plot",
        xlab="Species",
        ylab="Sepal Length")
b$out

