library(caret)

wineDf <- read.csv("wine_dataset.csv")
summary(wineDf)

processParams <- preProcess(wineDf[1:13],method = c("scale","center"))
print(processParams)
transformed <- predict(processParams, wineDf[1:13])
summary(transformed[1:13])

irisDf <- read.csv("iris_dataset.csv")
summary(irisDf)

processParams <- preProcess(irisDf[1:4],method = c("scale","center"))
print(processParams)
transformed <- predict(processParams, irisDf[1:4])
summary(transformed[1:4])
