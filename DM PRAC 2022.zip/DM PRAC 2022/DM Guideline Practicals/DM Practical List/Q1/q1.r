library(editrules)
file = read.csv('people.txt')
file
e = editfile("edits.txt")
ve = violatedEdits(e, file)
summary(ve)
par(mar=c(1,4,3,1))
plot(ve)
