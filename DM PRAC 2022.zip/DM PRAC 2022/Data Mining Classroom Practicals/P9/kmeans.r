library(ggplot2)

km <- kmeans(cars, 3)
km

cars$cluster<-factor(km$cluster)
cars

centers<-data.frame(cluster=factor(1:3),km$centers)

ggplot(data=cars, aes(x=speed, y=dist, shape=cluster, color=cluster))+
    geom_point(alpha=0.2)+
    geom_point(data=centers,aes(x=speed,y=dist),size=3,stroke=2)
