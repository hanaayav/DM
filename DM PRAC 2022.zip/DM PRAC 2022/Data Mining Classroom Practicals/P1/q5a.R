x1 <- c(1, 2, 3, 4, 5, 6, 5, 5)

x2 <- c(8, 9)	

x3 <- union(x1, x2)	

print(x3)									
