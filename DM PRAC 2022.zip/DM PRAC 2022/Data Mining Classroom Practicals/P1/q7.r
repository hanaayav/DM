fn <- function(x){
  y <- sin(x/2) + cos(x/2)
  print(y)
}

num = as.integer(readline("Enter a number: "))
fn(num)