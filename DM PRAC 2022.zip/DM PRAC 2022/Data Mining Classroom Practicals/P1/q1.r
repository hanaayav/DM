v = c(1, 2, NULL, 3, 4, NULL)
print("Original vector:")
print(v)
new_v = (v+7)[(!is.na(v)) & v > 0]
print("New vector:")
print(new_v)
