x1 <- c(1, 2, 3, 4, 5, 6, 5, 5)	
x2 <- c(2:4)	
x3 <- intersect(x1, x2)	

print(x3)				
