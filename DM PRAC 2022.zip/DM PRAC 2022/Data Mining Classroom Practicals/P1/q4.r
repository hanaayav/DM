rectangle <-function(a, b){
  area <- a*b
  print(area)
}

square <- function(side){
  area <- side*side
  print(area)
}

circle <- function(r){
  area <-pi*r*r
  print(area)
}

triangle <- function(b, h){
  area <- (b*h)/2
  print(area)
}

print("Calculate Area -")
var <- as.numeric(readline("1.Rec, 2.Square, 3.Circle, 4.Triangle: "))

switch(var,
1<-{
  x <- as.numeric(readline("Enter length"))
  y <- as.numeric(readline("Enter breadth"))
  rectangle(x, y)
  })
switch(var,
2<-{
  x <- as.numeric(readline("Enter Side"))
  square(x)
  })
switch(var,
3<-{
  x <- as.numeric(readline("Enter Radius"))
  circle(x)
  })
switch(var,
4<-{
  x <- as.numeric(readline("Enter base"))
  x <- as.numeric(readline("Enter height"))
  triangle(x, y)
  }
)