library(caret)

df <- read.csv("wine_dataset.csv")
summary(df[1:4])

#using both, we standardize the attr
cat("Data after standardizing")
processParams <- preProcess(df[1:4],method = c("scale","center"))
print(processParams)
transformed <- predict(processParams, df[1:4])
summary(transformed[1:4])

#normalization using range
cat("Data after normalizing")
processParams <- preProcess(df[1:4],method = c("range"))
print(processParams)
transformed <- predict(processParams, df[1:4])
summary(transformed[1:4])