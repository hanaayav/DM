library(caret)

df <- read.csv("iris_dataset.csv")
summary(df[1:4])

#scale: divide values of each attribute by the standard deviation of that attr.
processParams <- preProcess(df[1:4],method = c("scale"))
print(processParams)
transformed <- predict(processParams, df[1:4])
summary(transformed[1:4])

#center: subtract values from each attribute by the mean of that attr.
processParams <- preProcess(df[1:4],method = c("center"))
print(processParams)
transformed <- predict(processParams, df[1:4])
summary(transformed[1:4])

#using both, we standardize the attr
processParams <- preProcess(df[1:4],method = c("scale","center"))
print(processParams)
transformed <- predict(processParams, df[1:4])
summary(transformed[1:4])

#normalization using range
processParams <- preProcess(df[1:4],method = c("range"))
print(processParams)
transformed <- predict(processParams, df[1:4])
summary(transformed[1:4])