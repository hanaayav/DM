library(fpc)

cars

dbs <- dbscan(cars, eps=5, MinPts=3)
dbs

plot(dbs, cars)
