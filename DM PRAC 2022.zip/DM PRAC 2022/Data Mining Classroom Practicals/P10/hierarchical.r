id1 <- sample(1:dim(cars)[1],20)
id1

carsSample <- cars[id1,]
carsSample

hc <- hclust(dist(carsSample),method="ave")

plot(hc,hang=-1)

rect.hclust(hc,k=4)
