library(editrules)

x <- read.csv("https://raw.githubusercontent.com/edwindj/datacleaning/master/data/dirty_iris.csv")
x
# 1
count <- nrow(na.omit(x))
count
percentage <- (count/nrow(x)) * 100
percentage

# 2
x[is.nan(x)] <- NA
x[is.infinite(x)] <- NA

#3
e <- editfile("editRules")
e
#4
ve <- violatedEdits(e, x)
summary(ve)
plot(ve)

# 5
b <- boxplot(Sepal.Length ~ Species, data=x, 
        notch=TRUE,
        main="Box Plot",
        xlab="Species",
        ylab="Sepal Length")
b$out

