library(arules)
db <- read.transactions("F:\\Personal_Matters\\Parmeet\\Sem 6\\DM\\Association Rule Mining\\5000-out1.csv", sep=",", rm.duplicate=TRUE)
db
summary(db)
itemFrequencyPlot(db,topN=8)
rules = apriori(data = db, parameter = list(support = 0.05, confidence = 0.075))
rules
inspect(rules[1:10])
inspect(sort(rules, by = "confidence")[1:5])
inspect(sort(rules, by = "lift")[1:10])