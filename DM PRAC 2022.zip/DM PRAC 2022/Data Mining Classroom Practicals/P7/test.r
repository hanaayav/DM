library(arules)
db <- read.transactions("F:\\Personal_Matters\\Parmeet\\Sem 6\\DM\\Association Rule Mining\\1000-out1.csv", sep=",", rm.duplicate=TRUE)
db
summary(db)
itemFrequencyPlot(db,topN=10)
rules = apriori(data = db, parameter = list(support = 0.5, confidence = 0.006))
rules
inspect(rules[1:10])
inspect(sort(rules, by = "confidence")[20:40])
inspect(sort(rules, by = "lift")[1:20])