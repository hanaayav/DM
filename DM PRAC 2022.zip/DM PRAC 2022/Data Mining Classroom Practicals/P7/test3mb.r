library(arules)
db <- read.transactions("F:\\Personal_Matters\\Parmeet\\Sem 6\\DM\\Association Rule Mining\\Market_Basket.csv", sep=",", rm.duplicate=TRUE)
db
summary(db)
itemFrequencyPlot(db,topN=8)
rules = apriori(data = db, parameter = list(support = 0.06, confidence = 0.06))
rules
inspect(rules[1:10])
inspect(sort(rules, by = "confidence")[1:10])
inspect(sort(rules, by = "lift")[1:20])