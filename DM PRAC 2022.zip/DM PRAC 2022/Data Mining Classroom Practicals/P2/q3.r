df = read.csv('abalone.data', header=FALSE, col.names = c('Sex', 'Length', 'Diameter', 'Height', 'Whole Weight', 'Shucked Weight', 'Viscera Weight', 'Shell Weight', 'Rings'))

View(df)
str(df)
df$Length
df[456, ]
df[456, 'Length']
head(df, 100)
tail(df, 100)
levels(df$Length)
nrow(df)
ncol(df)
