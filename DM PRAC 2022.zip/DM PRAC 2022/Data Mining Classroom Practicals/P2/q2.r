df <- read.csv('Dirty android1 data.csv')
df

#NA in dataframe
sum(is.na(df))

#Number and percentage of complete
count <- nrow(na.omit(df))
count
percentage <- (count/nrow(df)) * 100
percentage

#Position of NA in LCOM
which(is.na(df$LCOM))

#Mean of each column
mean(df$MOA)
mean(df$MFA)
mean(df$CAM, na.rm=TRUE)
mean(df$IC)
mean(df$CBM, na.rm=TRUE)
mean(df$AMC)

#Replacing missing values by mean
cm1 <- df$MOA[is.na(df$MOA)] <- mean(df$MOA, na.rm=TRUE)
cm2 <- df$MFA[is.na(df$MFA)] <- mean(df$MFA, na.rm=TRUE)
cm3 <- df$CAM[is.na(df$CAM)] <- mean(df$CAM, na.rm=TRUE)
cm4 <- df$IC[is.na(df$IC)] <- mean(df$IC, na.rm=TRUE)
cm5 <- df$CBM[is.na(df$CBM)] <- mean(df$CBM, na.rm=TRUE)
cm6 <- df$AMC[is.na(df$AMC)] <- mean(df$AMC, na.rm=TRUE)
c(cm1, cm2, cm3, cm4, cm5, cm6)

#Omitting NA rows
df2 = read.csv('Dirty android1 data.csv')
df2 <- na.omit(df2)
df2

