cars

#Structure
str(cars)

#Arithmetic Mean
mean(cars$speed)
mean(cars$dist)

#Geometric Mean
exp(mean(log(cars$speed)))
exp(mean(log(cars$dist)))

#Harmonic Mean
1/mean(1/cars$speed)
1/mean(1/cars$dist)

#Median
median(cars$speed, na.rm=TRUE)
median(cars$dist, na.rm=TRUE)

#Unique dist values
unique(cars['dist'])

#Variance
var(cars$speed)
var(cars$dist)

#IQR of speed
IQR(cars$speed)

#Quartile
quantile(cars$dist, prob=c(seq(0.25, 1, by=0.25)))

