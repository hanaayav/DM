library(caret)
library(RWeka)
library(klaR)
library(dplyr)
library(e1071)

bcw <- read.csv("data.csv")
bcw <- subset(bcw, select = -X )

trainIndex <- createDataPartition(bcw$diagnosis, p=0.75, list=FALSE)

bcwTrain <- bcw[trainIndex, ]
bcwTest <- bcw[-trainIndex, ]

#Bootstrap
fitControlBoot <- trainControl(method="boot")
knnModelBoot <- train(diagnosis~., bcwTrain, method="knn", trControl=fitControlBoot)

predictionsBoot <- predict(knnModelBoot, bcwTest)

resultBoot <- confusionMatrix(predictionsBoot, as.factor(bcwTest$diagnosis))
knnBootAcc <- resultBoot$overall[['Accuracy']]
knnBootAcc

#Leave one out CV
fitControlLCV <- trainControl(method="loocv")
knnModelLCV <- train(diagnosis~., bcwTrain, method="knn", trControl=fitControlLCV)

predictionsLCV <- predict(knnModelLCV, bcwTest)

resultLCV <- confusionMatrix(predictionsLCV, as.factor(bcwTest$diagnosis))
knnLCVAcc <- resultLCV$overall[["Accuracy"]]
knnLCVAcc

#Cross Validation with 5 folds
fitControlCV <- trainControl(method="cv", number=20)
knnModelCV <- train(diagnosis~., bcwTrain, method="knn", trControl=fitControlCV)

predictionsCV <- predict(knnModelCV, bcwTest)

resultCV <- confusionMatrix(predictionsCV, as.factor(bcwTest$diagnosis))
knnCVAcc20 <- resultCV$overall[["Accuracy"]]
knnCVAcc20

#Repeated cv
fitControlRCV <- trainControl(method="repeatedcv", repeats=5, number=20)
knnModelRCV <- train(diagnosis~., bcwTrain, method="knn", trControl=fitControlRCV)

predictionsRCV <- predict(knnModelRCV, bcwTest)

resultRCV <- confusionMatrix(predictionsCV, as.factor(bcwTest$diagnosis))
knnRCVAcc20 <- resultRCV$overall[["Accuracy"]]
knnRCVAcc20


x <- c("Bootstrap", "LOOCV", "CV", "RCV")
y <- c(knnBootAcc, knnLCVAcc, knnCVAcc20, knnRCVAcc20)
qplot(x, y, xlab="Validation Methods", ylab="Accuracy")
