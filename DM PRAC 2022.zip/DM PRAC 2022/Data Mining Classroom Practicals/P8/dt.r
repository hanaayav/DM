library(caret)
library(RWeka)
library(klaR)
library(dplyr)
library(e1071)

bcw <- read.csv("data.csv")
bcw <- subset(bcw, select = -X )

trainIndex <- createDataPartition(bcw$diagnosis, p=0.75, list=FALSE)

bcwTrain <- bcw[trainIndex, ]
bcwTest <- bcw[-trainIndex, ]

#Bootstrap
fitControlBoot <- trainControl(method="boot")
modelBoot <- train(diagnosis~., bcwTrain, method="rpart", trControl=fitControlBoot)

predictionsBoot <- predict(modelBoot, bcwTest)

resultBoot <- confusionMatrix(predictionsBoot, as.factor(bcwTest$diagnosis))
bootAcc <- resultBoot$overall[['Accuracy']]
bootAcc

#Leave one out CV
fitControlLCV <- trainControl(method="loocv")
modelLCV <- train(diagnosis~., bcwTrain, method="rpart", trControl=fitControlLCV)

predictionsLCV <- predict(modelLCV, bcwTest)

resultLCV <- confusionMatrix(predictionsLCV, as.factor(bcwTest$diagnosis))
LCVAcc <- resultLCV$overall[["Accuracy"]]
LCVAcc

#Cross Validation with 20 folds
fitControlCV <- trainControl(method="cv", number=20)
modelCV <- train(diagnosis~., bcwTrain, method="rpart", trControl=fitControlCV)

predictionsCV <- predict(modelCV, bcwTest)

resultCV <- confusionMatrix(predictionsCV, as.factor(bcwTest$diagnosis))
CVAcc20 <- resultCV$overall[["Accuracy"]]
CVAcc20

#Repeated cv
fitControlRCV <- trainControl(method="repeatedcv", repeats=5, number=20)
modelRCV <- train(diagnosis~., bcwTrain, method="rpart", trControl=fitControlRCV)

predictionsRCV <- predict(knnModelRCV, bcwTest)

resultRCV <- confusionMatrix(predictionsCV, as.factor(bcwTest$diagnosis))
RCVAcc20 <- resultRCV$overall[["Accuracy"]]
RCVAcc20


x <- c("Bootstrap", "LOOCV", "CV", "RCV")
y <- c(bootAcc, LCVAcc, CVAcc20, RCVAcc20)
qplot(x, y, xlab="Validation Methods", ylab="Accuracy")
