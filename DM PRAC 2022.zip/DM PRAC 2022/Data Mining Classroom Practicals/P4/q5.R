y <- list("a", "b", "c")
names(y) <- c("one","two","three")