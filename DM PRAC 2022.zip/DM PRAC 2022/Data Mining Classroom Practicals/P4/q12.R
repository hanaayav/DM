x<- c(0,1,1,2,3,5,8,13,21,34,NA,11,NA)

#Mean and median
mean(x, na.rm=TRUE)
median(x, na.rm=TRUE)

#Squares of first nine
mat <- matrix((seq(1:9))^2, nrow=3, ncol=3, byrow=TRUE)
mat

#transpose
t(mat)

#multiply
mat2 <- matrix(seq(1:9), nrow=3, ncol=3, byrow=TRUE)
r = mat %*% mat2
r

#concat two lists
l1 = list(seq(1:5))
l2 = list(seq(6:10))
c(l1, l2)

#print even
v <- c(seq(1:10))
for (elem in v) {
  if (elem %% 2 == 0) {
    print(elem)
  }
}

#sort vector ascending
v <- c(seq(from=10, to=1, by=-1))
sort(v)