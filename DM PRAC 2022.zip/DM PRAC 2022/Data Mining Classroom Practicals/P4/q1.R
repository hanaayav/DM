my_list = list(Chr="hello", nums = 1:10, flag=TRUE)
print(my_list)