m1 <- matrix(
  c(7, 2, 9, 4, 12, 13),
  nrow = 2,
  ncol = 3
)

m2 <- matrix(
  c(1,2,3,7,8,9,12,13,14,19,20,21),
  nrow = 3,
  ncol = 4
)

m <- as.vector(m1)*m2

print(m)
