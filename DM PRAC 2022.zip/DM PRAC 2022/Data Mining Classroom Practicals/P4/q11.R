x <- as.integer(readline("Number of rows: "))
y <- as.integer(readline("Number of cols: "))
vals <- scan()

matrix(data = vals, ncol = y, nrow = x)
