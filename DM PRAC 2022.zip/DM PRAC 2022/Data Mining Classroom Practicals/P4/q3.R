Newlist <- list(a=1:10, b="Good morning", c="Hi")

Newlist$a = Newlist$a +1

Newlist$a #Or Newlist[1]