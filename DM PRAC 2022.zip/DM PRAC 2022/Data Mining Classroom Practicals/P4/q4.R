x <- list(a=5:10, c="Hello", d="AA")

x$z <- "NewItem"
