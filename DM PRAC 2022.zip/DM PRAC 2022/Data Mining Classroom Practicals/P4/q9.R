months_vector = c("January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December")
months_factor = ordered(months_vector, levels=months_vector)

months_factor