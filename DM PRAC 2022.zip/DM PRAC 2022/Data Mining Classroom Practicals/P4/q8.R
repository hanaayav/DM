a <- array(seq(from = 50, length.out = 15, by = 2), c(5, 3))
print("Content of the array:")
print("5�3 array of sequence of even integers greater than 50:")
print(a)
