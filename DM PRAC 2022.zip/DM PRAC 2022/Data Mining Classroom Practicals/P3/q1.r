library(editrules)
file = read.csv('q1people.txt')
file
e = editfile("q1edits.txt")
ve = violatedEdits(e, file)
summary(ve)
plot(ve)
