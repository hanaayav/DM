library(editrules)
file = read.csv("q2employee.txt")
file
e = editfile("q2edits.txt")
e
ve = violatedEdits(e, file)
summary(ve)
plot(ve)
